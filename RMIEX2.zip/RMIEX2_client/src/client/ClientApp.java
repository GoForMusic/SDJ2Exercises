package client;

import java.rmi.RemoteException;
import java.util.Scanner;

public class ClientApp {
    public static void main(String[] args) throws RemoteException {
        RmiClient client = new RmiClient();
        Scanner input = new Scanner(System.in);
        System.out.println("Enter the message: ");
        String line = input.nextLine();
        client.send(line);
    }
}
